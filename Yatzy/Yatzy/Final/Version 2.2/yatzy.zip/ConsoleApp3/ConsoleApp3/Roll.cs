﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Yatzy
{
    class Roll
    {
        public List<IDie> Dice { get; set; } = new List<IDie>();

        public Roll(int normalDice, int biasedDice)
        {
            for (var i = 0; i < normalDice; i++)
            {
                Dice.Add(new Die());
            }
            
            for (var i = 0; i < biasedDice; i++)
            {
                Dice.Add(new BiasedDie(true));
            }
        }

        public void RollDice(Random random)
        {
            foreach (var die in Dice)
            {
                if (!die.Locked)
                {
                    die.Roll(random);
                }

                die.Unlock();
            }
        }
    }
}
