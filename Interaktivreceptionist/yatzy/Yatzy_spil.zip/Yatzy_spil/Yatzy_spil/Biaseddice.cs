﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Yatzy_Mini_projekt
{
    public class BiasedDice : Dice
    {
        public BiasedDice(bool isFair)
        {

        }

        new public void Roll()
        {
            // 
        }
        //For at holde på en værdi, lav det så terningen kun rolles når du skriver du skal rolle med den.
    }
}