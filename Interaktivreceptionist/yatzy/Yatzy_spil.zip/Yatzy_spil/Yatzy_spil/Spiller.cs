﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Yatzy_spil
{
    class Spiller
    {

    }
}
